from django.apps import AppConfig


class FaceGroundConfig(AppConfig):
    name = 'face_ground'
