
# coding: utf-8

# In[4]:


from django.shortcuts import render
from django.http import HttpResponse,StreamingHttpResponse
import cv2
#import time
from time import gmtime, strftime
from django.views.decorators import gzip


# In[2]:


def process_soverana_frame(BGRframe):
    date_time= strftime("%Y-%m-%d %H:%M:%S", gmtime())
    cv2.putText(BGRframe, date_time, (10, 30),cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 3)
    
    
    return BGRframe


# In[5]:


class VideoCamera(object):
    def __init__(self):
        self.video = cv2.VideoCapture(0)
    def __del__(self):
        self.video.release()

    def get_jpgframe(self):
        ret,BGRframe = self.video.read()
        
        #SOVERANA code
        BGRframe=process_soverana_frame(BGRframe)
        #SOVERANA code
        
        ret,jpeg = cv2.imencode('.jpg',BGRframe)
        return jpeg.tobytes()


# In[7]:


def gen(camera):
    while True:
        frame = camera.get_jpgframe()
        yield(b'--frame\r\n'b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')


# In[10]:


@gzip.gzip_page
def index(request): 
    try:
        return StreamingHttpResponse(gen(VideoCamera()),content_type="multipart/x-mixed-replace;boundary=frame")
    except HttpResponseServerError as e:
        print("aborted")

