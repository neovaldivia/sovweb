from django.apps import AppConfig


class ImageRestConfig(AppConfig):
    name = 'image_rest'
