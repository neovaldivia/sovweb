from django.urls import path
#from . import views
from . import webtest_v3

urlpatterns = [
    #path('', views.index, name='index'),
	path('', webtest_v3.index, name='index2'),
]
