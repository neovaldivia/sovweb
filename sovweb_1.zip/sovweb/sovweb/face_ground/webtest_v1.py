
# coding: utf-8

# In[1]:

from django.shortcuts import render
from django.http import HttpResponse,StreamingHttpResponse
import cv2
import time
from django.views.decorators import gzip


# In[2]:

class VideoCamera(object):
    def __init__(self):
        self.video = cv2.VideoCapture(0)
    def __del__(self):
        self.video.release()

    def get_frame(self):
        ret,image = self.video.read()
        ret,jpeg = cv2.imencode('.jpg',image)
        return jpeg.tobytes()


# In[3]:

def gen(camera):
    while True:
        frame = camera.get_frame()
        yield(frame)
        time.sleep(1)


# In[4]:

def index(request):
    # response = HttpResponse(gen(VideoCamera())
    return StreamingHttpResponse(gen(VideoCamera()),content_type="multipart/x-mixed")

