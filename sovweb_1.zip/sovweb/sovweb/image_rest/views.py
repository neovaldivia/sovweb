from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from rest_framework.response import Response
from rest_framework import status
from .serializers import FileSerializer
import numpy as np
from numpy import frombuffer

from PIL import Image

import base64
import json
from django.core.files.base import ContentFile

# Create your views here.
class FileView(APIView):
    parser_classes = (MultiPartParser, FormParser, JSONParser)

    def post(self, request, *args, **kwargs):
        file_serializer = FileSerializer(data=request.data)
        # obj = json.loads(request.data)
        dataUrl = request.data['image']
        image = dataUrl.split(';base64,')[1]
        print(image)
        # file_serializer.Meta.model.file = ContentFile(base64.b64decode(image), name='temp.jpg')
        bytes = base64.b64decode(image)
        res = np.frombuffer(bytes, dtype=np.uint8)

        return Response(res, status.HTTP_200_OK)

        if file_serializer.is_valid():
            # file_serializer.save()
            return Response(file_serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(file_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
