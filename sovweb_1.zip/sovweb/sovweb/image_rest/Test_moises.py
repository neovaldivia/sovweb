import numpy as np
from PIL import Image

im = Image.open("pic.jpg")

print(im)
